﻿from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name, age):
        self._name = name
        self._age = age

    def get_name(self):
        return self._name

    def get_age(self):
        return self._age

    def set_name(self, name):
        self._name = name

    def set_age(self, age):
        self._age = age

    @abstractmethod
    def display_details(self):
        pass
