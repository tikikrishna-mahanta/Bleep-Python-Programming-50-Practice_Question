from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name, phone):
        self._name = name
        self.__phone = phone

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_phone(self):
        return self.__phone

    def set_phone(self, phone):
        self.__phone = phone

    @abstractmethod
    def display_details(self):
        pass


class Customer(Person):
    def __init__(self, customer_id, name, phone):
        super().__init__(name, phone)
        self.__customer_id = customer_id

    def get_customer_id(self):
        return self.__customer_id

    def display_details(self):
        print("Customer ID:", self.__customer_id)
        print("Name:", self._name)
        print("Phone:", self.get_phone())
