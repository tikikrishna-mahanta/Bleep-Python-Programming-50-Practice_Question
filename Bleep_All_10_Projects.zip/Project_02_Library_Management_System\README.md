# Library Management System

This is a console-based Library Management System developed using Python.

## Features

- Add books
- Display books
- Search for books
- Issue books
- Return books
- Add library members
- Display members
- Save book records to a CSV file
- Load book records from a CSV file
- Handle file errors and invalid data

## Classes

### Person

Person is an abstract base class containing common information for people in the library.

### Book

Book stores book information and keeps track of whether a book is available.

### Member

Member inherits from Person and stores library member information.

### Librarian

Librarian inherits from Person and stores librarian information.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- person.py
- book.py
- data/books.csv

## How to Run

Run the following command:

python main.py
