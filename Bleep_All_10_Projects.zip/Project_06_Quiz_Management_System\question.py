class Question:
    def __init__(self, question_id, question, option_a, option_b, option_c, option_d, answer):
        self.__question_id = question_id
        self.__question = question
        self.__options = {
            "A": option_a,
            "B": option_b,
            "C": option_c,
            "D": option_d
        }
        self.__answer = answer.upper()

    def get_question_id(self):
        return self.__question_id

    def get_question(self):
        return self.__question

    def get_options(self):
        return self.__options

    def get_answer(self):
        return self.__answer

    def display_question(self):
        print()
        print(self.__question)
        print("A.", self.__options["A"])
        print("B.", self.__options["B"])
        print("C.", self.__options["C"])
        print("D.", self.__options["D"])
