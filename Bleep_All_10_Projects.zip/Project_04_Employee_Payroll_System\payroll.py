from abc import ABC, abstractmethod


class Payroll(ABC):
    @abstractmethod
    def calculate_salary(self):
        pass


class EmployeePayroll(Payroll):
    def __init__(self, employee):
        self.__employee = employee

    def calculate_salary(self):
        basic_salary = self.__employee.get_basic_salary()
        allowance = basic_salary * 0.20
        deduction = basic_salary * 0.10
        net_salary = basic_salary + allowance - deduction

        return allowance, deduction, net_salary

    def display_salary(self):
        allowance, deduction, net_salary = self.calculate_salary()

        print("Basic Salary:", self.__employee.get_basic_salary())
        print("Allowance:", allowance)
        print("Deduction:", deduction)
        print("Net Salary:", net_salary)
