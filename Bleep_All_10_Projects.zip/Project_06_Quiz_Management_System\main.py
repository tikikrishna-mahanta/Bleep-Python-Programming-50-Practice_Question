from person import Participant
from quiz import Quiz


FILE_NAME = "data/questions.csv"


def main():
    quiz = Quiz()
    quiz.load_questions(FILE_NAME)

    participant_id = input("Enter participant ID: ")
    name = input("Enter participant name: ")

    participant = Participant(participant_id, name)

    while True:
        print()
        print("Quiz Management System")
        print("1. Start Quiz")
        print("2. Display Questions")
        print("3. Display Participant")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            quiz.start_quiz(participant)

        elif choice == "2":
            quiz.display_questions()

        elif choice == "3":
            participant.display_details()

        elif choice == "4":
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
