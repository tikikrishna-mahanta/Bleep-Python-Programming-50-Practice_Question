from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name):
        self._name = name

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    @abstractmethod
    def display_details(self):
        pass


class User(Person):
    def __init__(self, user_id, name):
        super().__init__(name)
        self.__user_id = user_id

    def get_user_id(self):
        return self.__user_id

    def display_details(self):
        print("User ID:", self.__user_id)
        print("Name:", self._name)
