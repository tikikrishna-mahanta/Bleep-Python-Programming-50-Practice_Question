class Doctor:
    def __init__(self, doctor_id, name, specialization):
        self.__doctor_id = doctor_id
        self.__name = name
        self.__specialization = specialization

    def get_doctor_id(self):
        return self.__doctor_id

    def get_name(self):
        return self.__name

    def get_specialization(self):
        return self.__specialization

    def display_details(self):
        print("Doctor ID:", self.__doctor_id)
        print("Name:", self.__name)
        print("Specialization:", self.__specialization)
