from person import Student
from registration import RegistrationSystem


FILE_NAME = "data/courses.csv"


def display_courses(system):
    courses = system.get_courses()

    if not courses:
        print("No courses found.")
        return

    for course in courses:
        print()
        course.display_details()


def register_student(system, student):
    course_id = input("Enter course ID: ")

    result = system.register(
        student.get_student_id(),
        course_id
    )

    print(result)


def main():
    system = RegistrationSystem()
    system.load_courses(FILE_NAME)

    student_id = input("Enter student ID: ")
    name = input("Enter student name: ")
    email = input("Enter student email: ")

    student = Student(
        student_id,
        name,
        email
    )

    while True:
        print()
        print("Course Registration System")
        print("1. Display Courses")
        print("2. Register for Course")
        print("3. Display Student")
        print("4. Save Courses")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            display_courses(system)

        elif choice == "2":
            register_student(system, student)

        elif choice == "3":
            student.display_details()

        elif choice == "4":
            system.save_courses(FILE_NAME)

        elif choice == "5":
            system.save_courses(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
