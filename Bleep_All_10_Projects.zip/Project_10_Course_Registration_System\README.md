# Course Registration System

This is a console-based Course Registration System developed using Python.

## Features

- Display available courses
- Register a student for a course
- Prevent duplicate registration
- Check available seats
- Display student details
- Save and load course records using CSV
- Handle invalid input and file errors

## Classes

Person is an abstract base class.

Student inherits from Person.

Course stores course information and available seats.

RegistrationSystem manages courses and student registrations.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements
