from person import Customer
from rental import RentalSystem


FILE_NAME = "data/vehicles.csv"


def add_vehicle(rental):
    vehicle_id = input("Enter vehicle ID: ")
    vehicle_type = input("Enter vehicle type: ")
    model = input("Enter model: ")

    try:
        rate = float(input("Enter daily rental rate: "))

        if rate < 0:
            print("Rate cannot be negative.")
            return

        if rental.find_vehicle(vehicle_id):
            print("Vehicle ID already exists.")
            return

        from vehicle import Vehicle
        vehicle = Vehicle(vehicle_id, vehicle_type, model, rate)
        rental.add_vehicle(vehicle)

        print("Vehicle added successfully.")

    except ValueError:
        print("Please enter a valid rate.")


def display_vehicles(rental):
    vehicles = rental.get_vehicles()

    if not vehicles:
        print("No vehicles found.")
        return

    for vehicle in vehicles:
        print()
        vehicle.display_details()


def rent_vehicle(rental):
    vehicle_id = input("Enter vehicle ID: ")

    if rental.rent_vehicle(vehicle_id):
        print("Vehicle rented successfully.")
    else:
        print("Vehicle is not available or does not exist.")


def return_vehicle(rental):
    vehicle_id = input("Enter vehicle ID: ")

    if rental.return_vehicle(vehicle_id):
        print("Vehicle returned successfully.")
    else:
        print("Vehicle not found.")


def main():
    rental = RentalSystem()
    rental.load_vehicles(FILE_NAME)

    customer_id = input("Enter customer ID: ")
    customer_name = input("Enter customer name: ")
    customer_phone = input("Enter customer phone: ")

    customer = Customer(
        customer_id,
        customer_name,
        customer_phone
    )

    while True:
        print()
        print("Vehicle Rental Management System")
        print("1. Add Vehicle")
        print("2. Display Vehicles")
        print("3. Rent Vehicle")
        print("4. Return Vehicle")
        print("5. Display Customer")
        print("6. Save Records")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_vehicle(rental)

        elif choice == "2":
            display_vehicles(rental)

        elif choice == "3":
            rent_vehicle(rental)

        elif choice == "4":
            return_vehicle(rental)

        elif choice == "5":
            customer.display_details()

        elif choice == "6":
            rental.save_vehicles(FILE_NAME)

        elif choice == "7":
            rental.save_vehicles(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
