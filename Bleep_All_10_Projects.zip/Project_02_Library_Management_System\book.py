from person import Person


class Book:
    def __init__(self, book_id, title, author):
        self.__book_id = book_id
        self.__title = title
        self.__author = author
        self.__available = True

    def get_book_id(self):
        return self.__book_id

    def get_title(self):
        return self.__title

    def get_author(self):
        return self.__author

    def is_available(self):
        return self.__available

    def set_title(self, title):
        self.__title = title

    def set_author(self, author):
        self.__author = author

    def set_available(self, available):
        self.__available = available

    def display_details(self):
        status = "Available" if self.__available else "Issued"

        print("Book ID:", self.__book_id)
        print("Title:", self.__title)
        print("Author:", self.__author)
        print("Status:", status)


class Member(Person):
    def __init__(self, member_id, name, phone):
        super().__init__(name, phone)
        self.__member_id = member_id

    def get_member_id(self):
        return self.__member_id

    def display_details(self):
        print("Member ID:", self.__member_id)
        print("Name:", self._name)
        print("Phone:", self._phone)


class Librarian(Person):
    def __init__(self, employee_id, name, phone):
        super().__init__(name, phone)
        self.__employee_id = employee_id

    def get_employee_id(self):
        return self.__employee_id

    def display_details(self):
        print("Employee ID:", self.__employee_id)
        print("Name:", self._name)
        print("Phone:", self._phone)
