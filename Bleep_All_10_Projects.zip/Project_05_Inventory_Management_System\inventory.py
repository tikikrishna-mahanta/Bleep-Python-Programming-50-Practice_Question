import csv
from item import Item


class Inventory:
    def __init__(self):
        self.__items = []

    def add_item(self, item):
        self.__items.append(item)

    def get_items(self):
        return self.__items

    def find_item(self, item_id):
        for item in self.__items:
            if item.get_item_id() == item_id:
                return item

        return None

    def remove_item(self, item_id):
        item = self.find_item(item_id)

        if item is None:
            return False

        self.__items.remove(item)
        return True

    def load_items(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    item = Item(
                        row["item_id"],
                        row["name"],
                        float(row["price"]),
                        int(row["quantity"])
                    )

                    self.add_item(item)

        except FileNotFoundError:
            print("Inventory file not found.")
        except ValueError:
            print("Invalid inventory data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_items(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fieldnames = [
                    "item_id",
                    "name",
                    "price",
                    "quantity"
                ]

                writer = csv.DictWriter(
                    file,
                    fieldnames=fieldnames
                )

                writer.writeheader()

                for item in self.__items:
                    writer.writerow({
                        "item_id": item.get_item_id(),
                        "name": item.get_name(),
                        "price": item.get_price(),
                        "quantity": item.get_quantity()
                    })

            print("Inventory saved successfully.")

        except OSError as error:
            print("File error:", error)
