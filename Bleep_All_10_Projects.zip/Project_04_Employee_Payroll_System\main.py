import csv
from employee import Employee
from payroll import EmployeePayroll


FILE_NAME = "data/employees.csv"


def load_employees():
    employees = []

    try:
        with open(FILE_NAME, "r", newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                employee = Employee(
                    row["employee_id"],
                    row["name"],
                    row["phone"],
                    row["department"],
                    float(row["basic_salary"])
                )

                employees.append(employee)

    except FileNotFoundError:
        print("Employee data file not found.")
    except ValueError:
        print("Invalid salary value in employee data.")
    except KeyError:
        print("Invalid CSV format.")
    except OSError as error:
        print("File error:", error)

    return employees


def save_employees(employees):
    try:
        with open(FILE_NAME, "w", newline="") as file:
            fieldnames = [
                "employee_id",
                "name",
                "phone",
                "department",
                "basic_salary"
            ]

            writer = csv.DictWriter(
                file,
                fieldnames=fieldnames
            )

            writer.writeheader()

            for employee in employees:
                writer.writerow({
                    "employee_id": employee.get_employee_id(),
                    "name": employee.get_name(),
                    "phone": employee.get_phone(),
                    "department": employee.get_department(),
                    "basic_salary": employee.get_basic_salary()
                })

        print("Employee records saved successfully.")

    except OSError as error:
        print("File error:", error)


def add_employee(employees):
    employee_id = input("Enter employee ID: ")
    name = input("Enter employee name: ")
    phone = input("Enter phone number: ")
    department = input("Enter department: ")

    try:
        basic_salary = float(input("Enter basic salary: "))

        if basic_salary < 0:
            print("Salary cannot be negative.")
            return

        for employee in employees:
            if employee.get_employee_id() == employee_id:
                print("Employee ID already exists.")
                return

        employee = Employee(
            employee_id,
            name,
            phone,
            department,
            basic_salary
        )

        employees.append(employee)
        print("Employee added successfully.")

    except ValueError:
        print("Please enter a valid salary.")


def display_employees(employees):
    if not employees:
        print("No employee records found.")
        return

    for employee in employees:
        print()
        employee.display_details()


def search_employee(employees):
    employee_id = input("Enter employee ID to search: ")

    for employee in employees:
        if employee.get_employee_id() == employee_id:
            print()
            employee.display_details()
            return

    print("Employee not found.")


def update_employee(employees):
    employee_id = input("Enter employee ID to update: ")

    for employee in employees:
        if employee.get_employee_id() == employee_id:
            name = input("Enter new name: ")
            phone = input("Enter new phone number: ")
            department = input("Enter new department: ")

            try:
                basic_salary = float(input("Enter new basic salary: "))

                if basic_salary < 0:
                    print("Salary cannot be negative.")
                    return

                employee.set_name(name)
                employee.set_phone(phone)
                employee.set_department(department)
                employee.set_basic_salary(basic_salary)

                print("Employee updated successfully.")
                return

            except ValueError:
                print("Please enter a valid salary.")
                return

    print("Employee not found.")


def delete_employee(employees):
    employee_id = input("Enter employee ID to delete: ")

    for employee in employees:
        if employee.get_employee_id() == employee_id:
            employees.remove(employee)
            print("Employee deleted successfully.")
            return

    print("Employee not found.")


def display_payroll(employees):
    employee_id = input("Enter employee ID: ")

    for employee in employees:
        if employee.get_employee_id() == employee_id:
            payroll = EmployeePayroll(employee)

            print()
            employee.display_details()
            print()
            payroll.display_salary()
            return

    print("Employee not found.")


def main():
    employees = load_employees()

    while True:
        print()
        print("Employee Payroll System")
        print("1. Add Employee")
        print("2. Display Employees")
        print("3. Search Employee")
        print("4. Update Employee")
        print("5. Delete Employee")
        print("6. Calculate Payroll")
        print("7. Save Employees")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_employee(employees)

        elif choice == "2":
            display_employees(employees)

        elif choice == "3":
            search_employee(employees)

        elif choice == "4":
            update_employee(employees)

        elif choice == "5":
            delete_employee(employees)

        elif choice == "6":
            display_payroll(employees)

        elif choice == "7":
            save_employees(employees)

        elif choice == "8":
            save_employees(employees)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
