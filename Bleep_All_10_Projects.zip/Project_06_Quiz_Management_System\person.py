from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name):
        self._name = name

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    @abstractmethod
    def display_details(self):
        pass


class Participant(Person):
    def __init__(self, participant_id, name):
        super().__init__(name)
        self.__participant_id = participant_id
        self.__score = 0

    def get_participant_id(self):
        return self.__participant_id

    def get_score(self):
        return self.__score

    def set_score(self, score):
        self.__score = score

    def display_details(self):
        print("Participant ID:", self.__participant_id)
        print("Name:", self._name)
        print("Score:", self.__score)
