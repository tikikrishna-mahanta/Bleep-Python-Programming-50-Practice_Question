﻿# Student Management System

This is a console-based Student Management System developed using Python.

## Features

- Add student records
- Display student records
- Search for a student
- Update student details
- Delete student records
- Save student records to a CSV file
- Load student records from a CSV file
- Handle invalid input and file errors

## Classes

### Person

Person is the abstract base class. It contains common student information such as name and age.

### Student

Student inherits from Person and contains student-specific information such as student ID, course and marks.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops and conditional statements

## Files

- main.py
- person.py
- student.py
- data/students.csv

## How to Run

Open the project folder in a terminal and run:

python main.py
