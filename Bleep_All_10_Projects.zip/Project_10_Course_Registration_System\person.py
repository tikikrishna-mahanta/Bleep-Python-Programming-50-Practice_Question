from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name, email):
        self._name = name
        self.__email = email

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_email(self):
        return self.__email

    def set_email(self, email):
        self.__email = email

    @abstractmethod
    def display_details(self):
        pass


class Student(Person):
    def __init__(self, student_id, name, email):
        super().__init__(name, email)
        self.__student_id = student_id

    def get_student_id(self):
        return self.__student_id

    def display_details(self):
        print("Student ID:", self.__student_id)
        print("Name:", self._name)
        print("Email:", self.get_email())
