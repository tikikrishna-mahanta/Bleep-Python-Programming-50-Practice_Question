# Expense Tracker

This is a console-based Expense Tracker developed using Python.

## Features

- Add expenses
- Display expenses
- Search expenses
- Remove expenses
- Calculate total expenses
- Display user details
- Save and load expense records using CSV
- Handle invalid input and file errors

## Classes

Person is an abstract base class.

User inherits from Person.

Expense stores individual expense information.

ExpenseTracker manages expense records and CSV operations.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements
