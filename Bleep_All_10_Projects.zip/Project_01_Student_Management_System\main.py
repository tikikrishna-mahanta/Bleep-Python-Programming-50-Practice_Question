﻿import csv
from student import Student


FILE_NAME = "data/students.csv"


def load_students():
    students = []

    try:
        with open(FILE_NAME, "r", newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                student = Student(
                    row["student_id"],
                    row["name"],
                    int(row["age"]),
                    row["course"],
                    float(row["marks"])
                )
                students.append(student)

    except FileNotFoundError:
        print("Student data file not found.")
    except ValueError:
        print("Invalid data found in the student file.")
    except OSError as error:
        print("File error:", error)

    return students


def save_students(students):
    try:
        with open(FILE_NAME, "w", newline="") as file:
            fieldnames = ["student_id", "name", "age", "course", "marks"]
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            writer.writeheader()

            for student in students:
                writer.writerow({
                    "student_id": student.get_student_id(),
                    "name": student.get_name(),
                    "age": student.get_age(),
                    "course": student.get_course(),
                    "marks": student.get_marks()
                })

        print("Student records saved successfully.")

    except OSError as error:
        print("File error:", error)


def add_student(students):
    try:
        student_id = input("Enter student ID: ")
        name = input("Enter student name: ")
        age = int(input("Enter student age: "))
        course = input("Enter course: ")
        marks = float(input("Enter marks: "))

        if age <= 0:
            print("Age must be greater than zero.")
            return

        if marks < 0 or marks > 100:
            print("Marks must be between 0 and 100.")
            return

        for student in students:
            if student.get_student_id() == student_id:
                print("Student ID already exists.")
                return

        student = Student(student_id, name, age, course, marks)
        students.append(student)

        print("Student added successfully.")

    except ValueError:
        print("Please enter valid numeric values for age and marks.")


def display_students(students):
    if not students:
        print("No student records found.")
        return

    for student in students:
        print()
        student.display_details()


def search_student(students):
    student_id = input("Enter student ID to search: ")

    for student in students:
        if student.get_student_id() == student_id:
            print()
            student.display_details()
            return

    print("Student not found.")


def update_student(students):
    student_id = input("Enter student ID to update: ")

    for student in students:
        if student.get_student_id() == student_id:
            try:
                name = input("Enter new name: ")
                age = int(input("Enter new age: "))
                course = input("Enter new course: ")
                marks = float(input("Enter new marks: "))

                if age <= 0:
                    print("Age must be greater than zero.")
                    return

                if marks < 0 or marks > 100:
                    print("Marks must be between 0 and 100.")
                    return

                student.set_name(name)
                student.set_age(age)
                student.set_course(course)
                student.set_marks(marks)

                print("Student updated successfully.")
                return

            except ValueError:
                print("Please enter valid numeric values.")
                return

    print("Student not found.")


def delete_student(students):
    student_id = input("Enter student ID to delete: ")

    for student in students:
        if student.get_student_id() == student_id:
            students.remove(student)
            print("Student deleted successfully.")
            return

    print("Student not found.")


def main():
    students = load_students()

    while True:
        print()
        print("Student Management System")
        print("1. Add Student")
        print("2. Display Students")
        print("3. Search Student")
        print("4. Update Student")
        print("5. Delete Student")
        print("6. Save Students")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_student(students)

        elif choice == "2":
            display_students(students)

        elif choice == "3":
            search_student(students)

        elif choice == "4":
            update_student(students)

        elif choice == "5":
            delete_student(students)

        elif choice == "6":
            save_students(students)

        elif choice == "7":
            save_students(students)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
