from abc import ABC, abstractmethod


class Account(ABC):
    def __init__(self, account_number, customer_id, balance):
        self.__account_number = account_number
        self.__customer_id = customer_id
        self.__balance = balance

    def get_account_number(self):
        return self.__account_number

    def get_customer_id(self):
        return self.__customer_id

    def get_balance(self):
        return self.__balance

    def set_balance(self, balance):
        self.__balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit amount must be greater than zero.")

        self.__balance += amount

    @abstractmethod
    def withdraw(self, amount):
        pass

    @abstractmethod
    def display_details(self):
        pass


class SavingsAccount(Account):
    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal amount must be greater than zero.")

        if amount > self.get_balance():
            raise ValueError("Insufficient balance.")

        self.set_balance(self.get_balance() - amount)

    def display_details(self):
        print("Account Number:", self.get_account_number())
        print("Customer ID:", self.get_customer_id())
        print("Account Type: Savings")
        print("Balance:", self.get_balance())
