# Bank Account Management System

This is a console-based Bank Account Management System developed using Python.

## Features

- Add customers
- Create bank accounts
- Display accounts
- Search accounts
- Deposit money
- Withdraw money
- Save account records to a CSV file
- Load account records from a CSV file
- Handle invalid input and file errors

## Classes

### Person

Person is an abstract base class containing common information for people.

### Customer

Customer inherits from Person and stores customer information.

### Account

Account is an abstract base class containing account information and common account operations.

### SavingsAccount

SavingsAccount inherits from Account and provides deposit and withdrawal functionality.

### Bank

Bank manages customers and accounts and handles CSV file operations.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- customer.py
- account.py
- bank.py
- data/accounts.csv

## How to Run

Run:

python main.py
