import csv
from book import Book, Member, Librarian


FILE_NAME = "data/books.csv"


def load_books():
    books = []

    try:
        with open(FILE_NAME, "r", newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                book = Book(
                    row["book_id"],
                    row["title"],
                    row["author"]
                )

                book.set_available(row["available"] == "True")
                books.append(book)

    except FileNotFoundError:
        print("Book data file not found.")
    except KeyError:
        print("Invalid book data format.")
    except OSError as error:
        print("File error:", error)

    return books


def save_books(books):
    try:
        with open(FILE_NAME, "w", newline="") as file:
            fieldnames = ["book_id", "title", "author", "available"]
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            writer.writeheader()

            for book in books:
                writer.writerow({
                    "book_id": book.get_book_id(),
                    "title": book.get_title(),
                    "author": book.get_author(),
                    "available": book.is_available()
                })

        print("Book records saved successfully.")

    except OSError as error:
        print("File error:", error)


def add_book(books):
    book_id = input("Enter book ID: ")
    title = input("Enter book title: ")
    author = input("Enter author name: ")

    for book in books:
        if book.get_book_id() == book_id:
            print("Book ID already exists.")
            return

    books.append(Book(book_id, title, author))
    print("Book added successfully.")


def display_books(books):
    if not books:
        print("No books found.")
        return

    for book in books:
        print()
        book.display_details()


def search_book(books):
    book_id = input("Enter book ID to search: ")

    for book in books:
        if book.get_book_id() == book_id:
            print()
            book.display_details()
            return

    print("Book not found.")


def issue_book(books):
    book_id = input("Enter book ID to issue: ")

    for book in books:
        if book.get_book_id() == book_id:
            if book.is_available():
                book.set_available(False)
                print("Book issued successfully.")
            else:
                print("Book is already issued.")
            return

    print("Book not found.")


def return_book(books):
    book_id = input("Enter book ID to return: ")

    for book in books:
        if book.get_book_id() == book_id:
            if not book.is_available():
                book.set_available(True)
                print("Book returned successfully.")
            else:
                print("Book is already available.")
            return

    print("Book not found.")


def add_member(members):
    member_id = input("Enter member ID: ")
    name = input("Enter member name: ")
    phone = input("Enter phone number: ")

    for member in members:
        if member.get_member_id() == member_id:
            print("Member ID already exists.")
            return

    members.append(Member(member_id, name, phone))
    print("Member added successfully.")


def display_members(members):
    if not members:
        print("No members found.")
        return

    for member in members:
        print()
        member.display_details()


def main():
    books = load_books()
    members = []

    librarian = Librarian("L001", "Library Admin", "0000000000")

    while True:
        print()
        print("Library Management System")
        print("1. Add Book")
        print("2. Display Books")
        print("3. Search Book")
        print("4. Issue Book")
        print("5. Return Book")
        print("6. Add Member")
        print("7. Display Members")
        print("8. Save Books")
        print("9. Display Librarian")
        print("10. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_book(books)

        elif choice == "2":
            display_books(books)

        elif choice == "3":
            search_book(books)

        elif choice == "4":
            issue_book(books)

        elif choice == "5":
            return_book(books)

        elif choice == "6":
            add_member(members)

        elif choice == "7":
            display_members(members)

        elif choice == "8":
            save_books(books)

        elif choice == "9":
            librarian.display_details()

        elif choice == "10":
            save_books(books)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
