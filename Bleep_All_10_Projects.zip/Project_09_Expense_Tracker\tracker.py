import csv
from expense import Expense


class ExpenseTracker:
    def __init__(self):
        self.__expenses = []

    def add_expense(self, expense):
        self.__expenses.append(expense)

    def get_expenses(self):
        return self.__expenses

    def find_expense(self, expense_id):
        for expense in self.__expenses:
            if expense.get_expense_id() == expense_id:
                return expense

        return None

    def remove_expense(self, expense_id):
        expense = self.find_expense(expense_id)

        if expense is None:
            return False

        self.__expenses.remove(expense)
        return True

    def get_total(self):
        total = 0

        for expense in self.__expenses:
            total += expense.get_amount()

        return total

    def load_expenses(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    expense = Expense(
                        row["expense_id"],
                        row["category"],
                        float(row["amount"]),
                        row["date"],
                        row["description"]
                    )

                    self.add_expense(expense)

        except FileNotFoundError:
            print("Expense file not found.")
        except ValueError:
            print("Invalid expense data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_expenses(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fields = [
                    "expense_id",
                    "category",
                    "amount",
                    "date",
                    "description"
                ]

                writer = csv.DictWriter(file, fieldnames=fields)
                writer.writeheader()

                for expense in self.__expenses:
                    writer.writerow({
                        "expense_id": expense.get_expense_id(),
                        "category": expense.get_category(),
                        "amount": expense.get_amount(),
                        "date": expense.get_date(),
                        "description": expense.get_description()
                    })

            print("Expenses saved successfully.")

        except OSError as error:
            print("File error:", error)
