class Item:
    def __init__(self, item_id, name, price, quantity):
        self.__item_id = item_id
        self.__name = name
        self.__price = price
        self.__quantity = quantity

    def get_item_id(self):
        return self.__item_id

    def get_name(self):
        return self.__name

    def get_price(self):
        return self.__price

    def get_quantity(self):
        return self.__quantity

    def set_name(self, name):
        self.__name = name

    def set_price(self, price):
        self.__price = price

    def set_quantity(self, quantity):
        self.__quantity = quantity

    def display_details(self):
        print("Item ID:", self.__item_id)
        print("Name:", self.__name)
        print("Price:", self.__price)
        print("Quantity:", self.__quantity)
