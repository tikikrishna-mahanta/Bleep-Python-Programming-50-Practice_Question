class Expense:
    def __init__(self, expense_id, category, amount, date, description):
        self.__expense_id = expense_id
        self.__category = category
        self.__amount = amount
        self.__date = date
        self.__description = description

    def get_expense_id(self):
        return self.__expense_id

    def get_category(self):
        return self.__category

    def get_amount(self):
        return self.__amount

    def get_date(self):
        return self.__date

    def get_description(self):
        return self.__description

    def set_category(self, category):
        self.__category = category

    def set_amount(self, amount):
        self.__amount = amount

    def set_date(self, date):
        self.__date = date

    def set_description(self, description):
        self.__description = description

    def display_details(self):
        print("Expense ID:", self.__expense_id)
        print("Category:", self.__category)
        print("Amount:", self.__amount)
        print("Date:", self.__date)
        print("Description:", self.__description)
