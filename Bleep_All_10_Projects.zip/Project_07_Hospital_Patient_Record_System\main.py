from person import Patient
from hospital import Hospital


FILE_NAME = "data/patients.csv"


def add_patient(hospital):
    patient_id = input("Enter patient ID: ")
    name = input("Enter patient name: ")

    try:
        age = int(input("Enter patient age: "))

        if age <= 0:
            print("Age must be greater than zero.")
            return

        phone = input("Enter phone number: ")
        disease = input("Enter disease: ")

        if hospital.find_patient(patient_id):
            print("Patient ID already exists.")
            return

        patient = Patient(
            patient_id,
            name,
            age,
            phone,
            disease
        )

        hospital.add_patient(patient)

        print("Patient added successfully.")

    except ValueError:
        print("Please enter a valid age.")


def display_patients(hospital):
    patients = hospital.get_patients()

    if not patients:
        print("No patient records found.")
        return

    for patient in patients:
        print()
        patient.display_details()


def search_patient(hospital):
    patient_id = input("Enter patient ID to search: ")

    patient = hospital.find_patient(patient_id)

    if patient:
        print()
        patient.display_details()
    else:
        print("Patient not found.")


def update_patient(hospital):
    patient_id = input("Enter patient ID to update: ")

    patient = hospital.find_patient(patient_id)

    if patient is None:
        print("Patient not found.")
        return

    try:
        age = int(input("Enter new age: "))

        if age <= 0:
            print("Age must be greater than zero.")
            return

        phone = input("Enter new phone number: ")
        disease = input("Enter new disease: ")

        patient.set_age(age)
        patient.set_phone(phone)
        patient.set_disease(disease)

        print("Patient updated successfully.")

    except ValueError:
        print("Please enter a valid age.")


def remove_patient(hospital):
    patient_id = input("Enter patient ID to remove: ")

    if hospital.remove_patient(patient_id):
        print("Patient removed successfully.")
    else:
        print("Patient not found.")


def main():
    hospital = Hospital()
    hospital.load_patients(FILE_NAME)

    while True:
        print()
        print("Hospital Patient Record System")
        print("1. Add Patient")
        print("2. Display Patients")
        print("3. Search Patient")
        print("4. Update Patient")
        print("5. Remove Patient")
        print("6. Save Records")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_patient(hospital)

        elif choice == "2":
            display_patients(hospital)

        elif choice == "3":
            search_patient(hospital)

        elif choice == "4":
            update_patient(hospital)

        elif choice == "5":
            remove_patient(hospital)

        elif choice == "6":
            hospital.save_patients(FILE_NAME)

        elif choice == "7":
            hospital.save_patients(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
