# Vehicle Rental Management System

This is a console-based Vehicle Rental Management System developed using Python.

## Features

- Add vehicles
- Display vehicles
- Rent vehicles
- Return vehicles
- Display customer details
- Save and load vehicle records using CSV
- Handle invalid input and file errors

## Classes

Person is an abstract base class.

Customer inherits from Person.

Vehicle stores vehicle information.

RentalSystem manages vehicle rental operations and CSV records.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements
