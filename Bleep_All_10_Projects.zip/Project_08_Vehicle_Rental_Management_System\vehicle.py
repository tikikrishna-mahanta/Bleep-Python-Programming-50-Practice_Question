class Vehicle:
    def __init__(self, vehicle_id, vehicle_type, model, rate):
        self.__vehicle_id = vehicle_id
        self.__vehicle_type = vehicle_type
        self.__model = model
        self.__rate = rate
        self.__available = True

    def get_vehicle_id(self):
        return self.__vehicle_id

    def get_vehicle_type(self):
        return self.__vehicle_type

    def get_model(self):
        return self.__model

    def get_rate(self):
        return self.__rate

    def is_available(self):
        return self.__available

    def set_rate(self, rate):
        self.__rate = rate

    def set_available(self, available):
        self.__available = available

    def display_details(self):
        print("Vehicle ID:", self.__vehicle_id)
        print("Type:", self.__vehicle_type)
        print("Model:", self.__model)
        print("Rate per day:", self.__rate)
        print("Available:", "Yes" if self.__available else "No")
