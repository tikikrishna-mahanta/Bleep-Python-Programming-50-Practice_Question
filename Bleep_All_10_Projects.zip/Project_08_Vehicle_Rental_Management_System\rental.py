import csv
from vehicle import Vehicle


class RentalSystem:
    def __init__(self):
        self.__vehicles = []

    def add_vehicle(self, vehicle):
        self.__vehicles.append(vehicle)

    def get_vehicles(self):
        return self.__vehicles

    def find_vehicle(self, vehicle_id):
        for vehicle in self.__vehicles:
            if vehicle.get_vehicle_id() == vehicle_id:
                return vehicle

        return None

    def rent_vehicle(self, vehicle_id):
        vehicle = self.find_vehicle(vehicle_id)

        if vehicle is None:
            return False

        if not vehicle.is_available():
            return False

        vehicle.set_available(False)
        return True

    def return_vehicle(self, vehicle_id):
        vehicle = self.find_vehicle(vehicle_id)

        if vehicle is None:
            return False

        vehicle.set_available(True)
        return True

    def load_vehicles(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    vehicle = Vehicle(
                        row["vehicle_id"],
                        row["vehicle_type"],
                        row["model"],
                        float(row["rate"])
                    )

                    vehicle.set_available(row["available"] == "True")
                    self.add_vehicle(vehicle)

        except FileNotFoundError:
            print("Vehicle file not found.")
        except ValueError:
            print("Invalid vehicle data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_vehicles(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fields = [
                    "vehicle_id",
                    "vehicle_type",
                    "model",
                    "rate",
                    "available"
                ]

                writer = csv.DictWriter(file, fieldnames=fields)
                writer.writeheader()

                for vehicle in self.__vehicles:
                    writer.writerow({
                        "vehicle_id": vehicle.get_vehicle_id(),
                        "vehicle_type": vehicle.get_vehicle_type(),
                        "model": vehicle.get_model(),
                        "rate": vehicle.get_rate(),
                        "available": vehicle.is_available()
                    })

            print("Vehicle records saved.")

        except OSError as error:
            print("File error:", error)
