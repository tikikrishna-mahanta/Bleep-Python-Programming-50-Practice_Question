from person import Person


class Employee(Person):
    def __init__(self, employee_id, name, phone, department, basic_salary):
        super().__init__(name, phone)
        self.__employee_id = employee_id
        self.__department = department
        self.__basic_salary = basic_salary

    def get_employee_id(self):
        return self.__employee_id

    def get_department(self):
        return self.__department

    def get_basic_salary(self):
        return self.__basic_salary

    def set_employee_id(self, employee_id):
        self.__employee_id = employee_id

    def set_department(self, department):
        self.__department = department

    def set_basic_salary(self, basic_salary):
        self.__basic_salary = basic_salary

    def display_details(self):
        print("Employee ID:", self.__employee_id)
        print("Name:", self._name)
        print("Phone:", self._phone)
        print("Department:", self.__department)
        print("Basic Salary:", self.__basic_salary)
