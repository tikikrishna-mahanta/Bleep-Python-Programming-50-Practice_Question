import csv
from account import SavingsAccount
from customer import Customer


class Bank:
    def __init__(self):
        self.__customers = []
        self.__accounts = []

    def add_customer(self, customer):
        self.__customers.append(customer)

    def add_account(self, account):
        self.__accounts.append(account)

    def get_customers(self):
        return self.__customers

    def get_accounts(self):
        return self.__accounts

    def find_account(self, account_number):
        for account in self.__accounts:
            if account.get_account_number() == account_number:
                return account

        return None

    def find_customer(self, customer_id):
        for customer in self.__customers:
            if customer.get_customer_id() == customer_id:
                return customer

        return None

    def load_accounts(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    customer = Customer(
                        row["customer_id"],
                        row["name"],
                        row["phone"]
                    )

                    account = SavingsAccount(
                        row["account_number"],
                        row["customer_id"],
                        float(row["balance"])
                    )

                    self.add_customer(customer)
                    self.add_account(account)

        except FileNotFoundError:
            print("Account data file not found.")
        except ValueError:
            print("Invalid account data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_accounts(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fieldnames = [
                    "customer_id",
                    "name",
                    "phone",
                    "account_number",
                    "balance"
                ]

                writer = csv.DictWriter(
                    file,
                    fieldnames=fieldnames
                )

                writer.writeheader()

                for account in self.__accounts:
                    customer = self.find_customer(
                        account.get_customer_id()
                    )

                    writer.writerow({
                        "customer_id": customer.get_customer_id(),
                        "name": customer.get_name(),
                        "phone": customer.get_phone(),
                        "account_number": account.get_account_number(),
                        "balance": account.get_balance()
                    })

            print("Account records saved successfully.")

        except OSError as error:
            print("File error:", error)
