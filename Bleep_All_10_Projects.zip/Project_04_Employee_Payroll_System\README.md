# Employee Payroll System

This is a console-based Employee Payroll System developed using Python.

## Features

- Add employee records
- Display employee records
- Search employees
- Update employee details
- Delete employee records
- Calculate employee payroll
- Save employee records to CSV
- Load employee records from CSV
- Handle invalid input and file errors

## Classes

### Person

Person is an abstract base class containing common personal information.

### Employee

Employee inherits from Person and stores employee information.

### Payroll

Payroll is an abstract base class for salary calculation.

### EmployeePayroll

EmployeePayroll implements payroll calculation for an employee.

## Payroll Calculation

The program uses the following calculation:

- Allowance = 20% of basic salary
- Deduction = 10% of basic salary
- Net Salary = Basic Salary + Allowance - Deduction

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- person.py
- employee.py
- payroll.py
- data/employees.csv

## How to Run

Run:

python main.py
