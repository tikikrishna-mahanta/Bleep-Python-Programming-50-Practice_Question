# Hospital Patient Record System

This is a console-based Hospital Patient Record System developed using Python.

## Features

- Add patient records
- Display patient records
- Search patients
- Update patient details
- Remove patient records
- Save records to CSV
- Load records from CSV
- Handle invalid input and file errors

## Classes

### Person

Person is an abstract base class.

### Patient

Patient inherits from Person and stores patient information.

### Doctor

Doctor stores doctor information and specialization.

### Hospital

Hospital manages patient records and CSV file operations.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- person.py
- doctor.py
- hospital.py
- data/patients.csv

## How to Run

Run:

python main.py
