class Course:
    def __init__(self, course_id, name, instructor, seats):
        self.__course_id = course_id
        self.__name = name
        self.__instructor = instructor
        self.__seats = seats

    def get_course_id(self):
        return self.__course_id

    def get_name(self):
        return self.__name

    def get_instructor(self):
        return self.__instructor

    def get_seats(self):
        return self.__seats

    def set_name(self, name):
        self.__name = name

    def set_instructor(self, instructor):
        self.__instructor = instructor

    def set_seats(self, seats):
        self.__seats = seats

    def register_student(self):
        if self.__seats <= 0:
            return False

        self.__seats -= 1
        return True

    def display_details(self):
        print("Course ID:", self.__course_id)
        print("Course:", self.__name)
        print("Instructor:", self.__instructor)
        print("Available Seats:", self.__seats)
