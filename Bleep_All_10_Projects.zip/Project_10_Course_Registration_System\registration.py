import csv
from course import Course


class RegistrationSystem:
    def __init__(self):
        self.__courses = []
        self.__registrations = []

    def add_course(self, course):
        self.__courses.append(course)

    def get_courses(self):
        return self.__courses

    def find_course(self, course_id):
        for course in self.__courses:
            if course.get_course_id() == course_id:
                return course

        return None

    def is_registered(self, student_id, course_id):
        for registration in self.__registrations:
            if (
                registration["student_id"] == student_id
                and registration["course_id"] == course_id
            ):
                return True

        return False

    def register(self, student_id, course_id):
        course = self.find_course(course_id)

        if course is None:
            return "Course not found."

        if self.is_registered(student_id, course_id):
            return "Student is already registered."

        if not course.register_student():
            return "No seats available."

        self.__registrations.append({
            "student_id": student_id,
            "course_id": course_id
        })

        return "Registration successful."

    def load_courses(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    course = Course(
                        row["course_id"],
                        row["name"],
                        row["instructor"],
                        int(row["seats"])
                    )

                    self.add_course(course)

        except FileNotFoundError:
            print("Course file not found.")
        except ValueError:
            print("Invalid course data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_courses(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fields = [
                    "course_id",
                    "name",
                    "instructor",
                    "seats"
                ]

                writer = csv.DictWriter(file, fieldnames=fields)
                writer.writeheader()

                for course in self.__courses:
                    writer.writerow({
                        "course_id": course.get_course_id(),
                        "name": course.get_name(),
                        "instructor": course.get_instructor(),
                        "seats": course.get_seats()
                    })

            print("Course records saved.")

        except OSError as error:
            print("File error:", error)
