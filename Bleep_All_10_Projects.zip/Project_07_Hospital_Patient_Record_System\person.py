from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name, phone):
        self._name = name
        self.__phone = phone

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_phone(self):
        return self.__phone

    def set_phone(self, phone):
        self.__phone = phone

    @abstractmethod
    def display_details(self):
        pass


class Patient(Person):
    def __init__(self, patient_id, name, age, phone, disease):
        super().__init__(name, phone)
        self.__patient_id = patient_id
        self.__age = age
        self.__disease = disease

    def get_patient_id(self):
        return self.__patient_id

    def get_age(self):
        return self.__age

    def get_disease(self):
        return self.__disease

    def set_age(self, age):
        self.__age = age

    def set_disease(self, disease):
        self.__disease = disease

    def display_details(self):
        print("Patient ID:", self.__patient_id)
        print("Name:", self._name)
        print("Age:", self.__age)
        print("Phone:", self.get_phone())
        print("Disease:", self.__disease)
