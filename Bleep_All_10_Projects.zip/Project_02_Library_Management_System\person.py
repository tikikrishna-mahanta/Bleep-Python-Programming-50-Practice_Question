from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name, phone):
        self._name = name
        self._phone = phone

    def get_name(self):
        return self._name

    def get_phone(self):
        return self._phone

    def set_name(self, name):
        self._name = name

    def set_phone(self, phone):
        self._phone = phone

    @abstractmethod
    def display_details(self):
        pass
