import csv
from person import Patient


class Hospital:
    def __init__(self):
        self.__patients = []

    def add_patient(self, patient):
        self.__patients.append(patient)

    def get_patients(self):
        return self.__patients

    def find_patient(self, patient_id):
        for patient in self.__patients:
            if patient.get_patient_id() == patient_id:
                return patient

        return None

    def remove_patient(self, patient_id):
        patient = self.find_patient(patient_id)

        if patient is None:
            return False

        self.__patients.remove(patient)
        return True

    def load_patients(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    patient = Patient(
                        row["patient_id"],
                        row["name"],
                        int(row["age"]),
                        row["phone"],
                        row["disease"]
                    )

                    self.add_patient(patient)

        except FileNotFoundError:
            print("Patient file not found.")
        except ValueError:
            print("Invalid patient data.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def save_patients(self, file_name):
        try:
            with open(file_name, "w", newline="") as file:
                fieldnames = [
                    "patient_id",
                    "name",
                    "age",
                    "phone",
                    "disease"
                ]

                writer = csv.DictWriter(
                    file,
                    fieldnames=fieldnames
                )

                writer.writeheader()

                for patient in self.__patients:
                    writer.writerow({
                        "patient_id": patient.get_patient_id(),
                        "name": patient.get_name(),
                        "age": patient.get_age(),
                        "phone": patient.get_phone(),
                        "disease": patient.get_disease()
                    })

            print("Patient records saved successfully.")

        except OSError as error:
            print("File error:", error)
