﻿from person import Person


class Student(Person):
    def __init__(self, student_id, name, age, course, marks):
        super().__init__(name, age)
        self.__student_id = student_id
        self.__course = course
        self.__marks = marks

    def get_student_id(self):
        return self.__student_id

    def get_course(self):
        return self.__course

    def get_marks(self):
        return self.__marks

    def set_student_id(self, student_id):
        self.__student_id = student_id

    def set_course(self, course):
        self.__course = course

    def set_marks(self, marks):
        self.__marks = marks

    def display_details(self):
        print("Student ID:", self.__student_id)
        print("Name:", self._name)
        print("Age:", self._age)
        print("Course:", self.__course)
        print("Marks:", self.__marks)
