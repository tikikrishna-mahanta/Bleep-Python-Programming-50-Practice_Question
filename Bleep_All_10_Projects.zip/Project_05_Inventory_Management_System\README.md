# Inventory Management System

This is a console-based Inventory Management System developed using Python.

## Features

- Add inventory items
- Display inventory items
- Search items
- Update item details
- Remove items
- Save inventory records to a CSV file
- Load inventory records from a CSV file
- Handle invalid input and file errors

## Classes

### Person

Person is an abstract base class.

### Supplier

Supplier inherits from Person and stores supplier information.

### Item

Item stores inventory information such as item ID, name, price and quantity.

### Inventory

Inventory manages item records and CSV file operations.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- item.py
- inventory.py
- person.py
- data/inventory.csv

## How to Run

Run:

python main.py
