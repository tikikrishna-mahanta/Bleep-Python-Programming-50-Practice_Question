from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name):
        self._name = name

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    @abstractmethod
    def display_details(self):
        pass


class Supplier(Person):
    def __init__(self, supplier_id, name, phone):
        super().__init__(name)
        self.__supplier_id = supplier_id
        self.__phone = phone

    def get_supplier_id(self):
        return self.__supplier_id

    def get_phone(self):
        return self.__phone

    def set_phone(self, phone):
        self.__phone = phone

    def display_details(self):
        print("Supplier ID:", self.__supplier_id)
        print("Name:", self._name)
        print("Phone:", self.__phone)
