# Quiz Management System

This is a console-based Quiz Management System developed using Python.

## Features

- Load quiz questions from a CSV file
- Start a quiz
- Check answers
- Calculate participant score
- Display participant details
- Handle invalid answers
- Handle CSV file errors

## Classes

### Person

Person is an abstract base class.

### Participant

Participant inherits from Person and stores participant information and score.

### Question

Question stores question text, four options and the correct answer.

### Quiz

Quiz manages questions, loads CSV data and runs the quiz.

## Concepts Used

- Classes and objects
- Encapsulation
- Inheritance
- Abstraction
- Getters and setters
- CSV file handling
- Exception handling
- Functions
- Loops
- Conditional statements

## Files

- main.py
- person.py
- question.py
- quiz.py
- data/questions.csv

## How to Run

Run:

python main.py
