import csv
from question import Question


class Quiz:
    def __init__(self):
        self.__questions = []

    def add_question(self, question):
        self.__questions.append(question)

    def get_questions(self):
        return self.__questions

    def load_questions(self, file_name):
        try:
            with open(file_name, "r", newline="") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    question = Question(
                        row["question_id"],
                        row["question"],
                        row["option_a"],
                        row["option_b"],
                        row["option_c"],
                        row["option_d"],
                        row["answer"]
                    )

                    self.add_question(question)

        except FileNotFoundError:
            print("Question file not found.")
        except KeyError:
            print("Invalid CSV format.")
        except OSError as error:
            print("File error:", error)

    def display_questions(self):
        for question in self.__questions:
            question.display_question()

    def start_quiz(self, participant):
        score = 0

        if not self.__questions:
            print("No questions available.")
            return

        for question in self.__questions:
            question.display_question()

            while True:
                answer = input("Enter your answer (A/B/C/D): ").strip().upper()

                if answer in ["A", "B", "C", "D"]:
                    break

                print("Invalid answer. Please enter A, B, C or D.")

            if answer == question.get_answer():
                print("Correct!")
                score += 1
            else:
                print("Wrong.")
                print("Correct answer:", question.get_answer())

        participant.set_score(score)

        print()
        print("Quiz completed.")
        print("Participant:", participant.get_name())
        print("Score:", score, "/", len(self.__questions))
