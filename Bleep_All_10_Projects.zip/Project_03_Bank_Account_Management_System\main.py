from bank import Bank
from account import SavingsAccount
from customer import Customer


FILE_NAME = "data/accounts.csv"


def add_customer(bank):
    customer_id = input("Enter customer ID: ")
    name = input("Enter customer name: ")
    phone = input("Enter phone number: ")

    if bank.find_customer(customer_id):
        print("Customer ID already exists.")
        return

    customer = Customer(customer_id, name, phone)
    bank.add_customer(customer)

    print("Customer added successfully.")


def create_account(bank):
    customer_id = input("Enter customer ID: ")

    customer = bank.find_customer(customer_id)

    if customer is None:
        print("Customer not found.")
        return

    account_number = input("Enter account number: ")

    if bank.find_account(account_number):
        print("Account number already exists.")
        return

    try:
        balance = float(input("Enter opening balance: "))

        if balance < 0:
            print("Balance cannot be negative.")
            return

        account = SavingsAccount(
            account_number,
            customer_id,
            balance
        )

        bank.add_account(account)

        print("Account created successfully.")

    except ValueError:
        print("Please enter a valid balance.")


def display_accounts(bank):
    accounts = bank.get_accounts()

    if not accounts:
        print("No accounts found.")
        return

    for account in accounts:
        print()
        account.display_details()


def search_account(bank):
    account_number = input("Enter account number: ")

    account = bank.find_account(account_number)

    if account:
        print()
        account.display_details()
    else:
        print("Account not found.")


def deposit_money(bank):
    account_number = input("Enter account number: ")

    account = bank.find_account(account_number)

    if account is None:
        print("Account not found.")
        return

    try:
        amount = float(input("Enter deposit amount: "))
        account.deposit(amount)
        print("Money deposited successfully.")
        print("New balance:", account.get_balance())

    except ValueError as error:
        print(error)


def withdraw_money(bank):
    account_number = input("Enter account number: ")

    account = bank.find_account(account_number)

    if account is None:
        print("Account not found.")
        return

    try:
        amount = float(input("Enter withdrawal amount: "))
        account.withdraw(amount)
        print("Money withdrawn successfully.")
        print("New balance:", account.get_balance())

    except ValueError as error:
        print(error)


def main():
    bank = Bank()
    bank.load_accounts(FILE_NAME)

    while True:
        print()
        print("Bank Account Management System")
        print("1. Add Customer")
        print("2. Create Account")
        print("3. Display Accounts")
        print("4. Search Account")
        print("5. Deposit Money")
        print("6. Withdraw Money")
        print("7. Save Accounts")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_customer(bank)

        elif choice == "2":
            create_account(bank)

        elif choice == "3":
            display_accounts(bank)

        elif choice == "4":
            search_account(bank)

        elif choice == "5":
            deposit_money(bank)

        elif choice == "6":
            withdraw_money(bank)

        elif choice == "7":
            bank.save_accounts(FILE_NAME)

        elif choice == "8":
            bank.save_accounts(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
