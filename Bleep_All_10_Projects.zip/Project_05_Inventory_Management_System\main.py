from inventory import Inventory
from item import Item


FILE_NAME = "data/inventory.csv"


def add_item(inventory):
    item_id = input("Enter item ID: ")
    name = input("Enter item name: ")

    try:
        price = float(input("Enter item price: "))
        quantity = int(input("Enter quantity: "))

        if price < 0 or quantity < 0:
            print("Price and quantity cannot be negative.")
            return

        if inventory.find_item(item_id):
            print("Item ID already exists.")
            return

        item = Item(item_id, name, price, quantity)
        inventory.add_item(item)

        print("Item added successfully.")

    except ValueError:
        print("Please enter valid price and quantity.")


def display_items(inventory):
    items = inventory.get_items()

    if not items:
        print("No inventory records found.")
        return

    for item in items:
        print()
        item.display_details()


def search_item(inventory):
    item_id = input("Enter item ID to search: ")

    item = inventory.find_item(item_id)

    if item:
        print()
        item.display_details()
    else:
        print("Item not found.")


def update_item(inventory):
    item_id = input("Enter item ID to update: ")

    item = inventory.find_item(item_id)

    if item is None:
        print("Item not found.")
        return

    name = input("Enter new item name: ")

    try:
        price = float(input("Enter new price: "))
        quantity = int(input("Enter new quantity: "))

        if price < 0 or quantity < 0:
            print("Price and quantity cannot be negative.")
            return

        item.set_name(name)
        item.set_price(price)
        item.set_quantity(quantity)

        print("Item updated successfully.")

    except ValueError:
        print("Please enter valid price and quantity.")


def remove_item(inventory):
    item_id = input("Enter item ID to remove: ")

    if inventory.remove_item(item_id):
        print("Item removed successfully.")
    else:
        print("Item not found.")


def main():
    inventory = Inventory()
    inventory.load_items(FILE_NAME)

    while True:
        print()
        print("Inventory Management System")
        print("1. Add Item")
        print("2. Display Items")
        print("3. Search Item")
        print("4. Update Item")
        print("5. Remove Item")
        print("6. Save Inventory")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_item(inventory)

        elif choice == "2":
            display_items(inventory)

        elif choice == "3":
            search_item(inventory)

        elif choice == "4":
            update_item(inventory)

        elif choice == "5":
            remove_item(inventory)

        elif choice == "6":
            inventory.save_items(FILE_NAME)

        elif choice == "7":
            inventory.save_items(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
