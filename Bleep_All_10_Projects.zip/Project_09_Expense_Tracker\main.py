from person import User
from expense import Expense
from tracker import ExpenseTracker


FILE_NAME = "data/expenses.csv"


def add_expense(tracker):
    expense_id = input("Enter expense ID: ")
    category = input("Enter category: ")

    try:
        amount = float(input("Enter amount: "))

        if amount < 0:
            print("Amount cannot be negative.")
            return

        date = input("Enter date: ")
        description = input("Enter description: ")

        if tracker.find_expense(expense_id):
            print("Expense ID already exists.")
            return

        expense = Expense(
            expense_id,
            category,
            amount,
            date,
            description
        )

        tracker.add_expense(expense)
        print("Expense added successfully.")

    except ValueError:
        print("Please enter a valid amount.")


def display_expenses(tracker):
    expenses = tracker.get_expenses()

    if not expenses:
        print("No expenses found.")
        return

    for expense in expenses:
        print()
        expense.display_details()


def search_expense(tracker):
    expense_id = input("Enter expense ID: ")

    expense = tracker.find_expense(expense_id)

    if expense:
        expense.display_details()
    else:
        print("Expense not found.")


def remove_expense(tracker):
    expense_id = input("Enter expense ID: ")

    if tracker.remove_expense(expense_id):
        print("Expense removed successfully.")
    else:
        print("Expense not found.")


def main():
    tracker = ExpenseTracker()
    tracker.load_expenses(FILE_NAME)

    user_id = input("Enter user ID: ")
    name = input("Enter user name: ")

    user = User(user_id, name)

    while True:
        print()
        print("Expense Tracker")
        print("1. Add Expense")
        print("2. Display Expenses")
        print("3. Search Expense")
        print("4. Remove Expense")
        print("5. Total Expense")
        print("6. Display User")
        print("7. Save Expenses")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_expense(tracker)

        elif choice == "2":
            display_expenses(tracker)

        elif choice == "3":
            search_expense(tracker)

        elif choice == "4":
            remove_expense(tracker)

        elif choice == "5":
            print("Total Expense:", tracker.get_total())

        elif choice == "6":
            user.display_details()

        elif choice == "7":
            tracker.save_expenses(FILE_NAME)

        elif choice == "8":
            tracker.save_expenses(FILE_NAME)
            print("Program closed.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
